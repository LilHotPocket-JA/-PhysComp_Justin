
let port;               // variable for serial port instance
let baudRate = 115200;
let rxFlag = false;         // boolean to flag when new data has been received
let firstContact = false;   // boolean to flag when 1st contact has been made with serial port
let sensors = [0, 0]; // declare array for incoming sensor data, and initialize with zeros
let pot1 = 0;               
let pot2 = 0;    

let xC = 0; //x Circle- x position of puck 
let yC = 0; //y Circle - y position of puck 

//saves default position of xC and yC 
let defaultX = 0;
let defaultY = 0;
let speed = 5;//speed of objects

let redS = 0;
let blueS = 0; 

function setup() 
{
  //P5 Sketch Setup
  createCanvas(500, 500);
  textAlign(CENTER, CENTER);
  textSize(24);
  strokeWeight(4);
  stroke(127);

  let xC = width/2;
  let yC = height/2;  
  defaultX = xC;
  defaultY = yC;

  //P5 Serial Setup
  port = createSerial(); // make a new instance of the serial port

  // if we've connected to a serial port before, reopen it
  let used = usedSerialPorts();
  if (used.length > 0) 
  {
    port.open(used[0], baudRate);
  }
}



function draw() 
{

  //____SERIAL_Rx/Tx_START____
  let inString = port.readUntil('\n'); // read incoming serial data until newline
  if (inString.length > 0)  //if we actually received data...
  {
    firstContact = true;  // we have made contact, set firstContact to true
    print(inString);

    if (rxFlag)  //if rxFlag is true...
    {
      sensors = inString.split(','); // split at commas, store in array

      if (sensors.length >= 2) 
      {
        
        pot1 = floor(map(Number(sensors[0]), 0, 1023, 0, height-60)); // map pot 1 to 0-255
        pot2 = floor(map(Number(sensors[1]), 0, 1023, 0, height-60)); // map pot 2 to 0-255

        port.write('A');  //ask for the next reading
      }
    }
  }
  //____SERIAL_Rx/Tx_END____

  background(0);
  stroke(127);

  if (!firstContact)  //if we have not yet received any data...
  {
  // display "Waiting" page
    background(0, 0, 127);
    fill(255);
    noStroke();
    text("Waiting for First Contact", width/2, height/4);
    text("Click Circle to Begin", width/2, height/3);
    circle(width/2, height/2, 140);
    fill(0);
    text("START RX", width/2, height/2);
  }

  else
  {
    fill(255,0,0);
    rect(10,pot1,30,60);//Red Padddle 
    fill(0,0,255);
    rect(width-40,pot2,30,60);//Blue Paddle 

    fill(255);
    noStroke();
    circle(xC,yC,10);
    xC += speed;

    fill(0);
    if((yC > pot1 - 30 && yC < pot1 + 60) && xC == 25)// If it hits red
    {
      xC += -speed + 1; 
      yC += Math.random() * (-speed  - speed + 1) + speed;
    }

    if((yC > pot2 - 30 && yC < pot2 + 60) &&  xC == width-45)//If it hits blue 
    {
      xC += -speed - 1;
      yC += Math.random() * (-speed  - speed + 1) + speed;
    }

    if(yC < 0) //if it tries to go out of bounds 
    {
      yC += speed;
      xC += Math.random() * (-speed  - speed + 1) + speed;
    }

    else if(yC > height)
    {
       yC = speed;
      xC += Math.random() * (-speed  - speed + 1) + speed;
    }

    if(xC < 0)
      {
        xC = defaultX;
        yC = defaultY;
        speed = -speed;
        redS++;
        port.write('R');
      }

      else if(xC > width)
      {
        xC = defaultX;
        yC = defaultY;
        speed = -speed;
        blueS++;
        port.write('C');
      }

    fill(255,0,0);
    noStroke();
    text("Score: " + redS, 55, 15);

    fill(0,0,255);
    noStroke();
    text("Score: " + blueS, width-55, height-15);
    

    if (rxFlag) // if rxFlag is true, we are receiving data, so...
    {
      fill(0);
      noStroke();
      speed = 3;
      text("PAUSE RX", width/2, height/2);  // display "PAUSE RX" on the button
    }

    else  //if rxFlag is false, we are not receiving data, so...
    {
      fill(255, 0, 0 );
      noStroke();
      speed = 0;
      text("PAUSED", width/2, height/2);  //display "PAUSED" on the button
    }
  
  } 
}

function mousePressed() //if mouse is pressed...
{
  if (dist(mouseX, mouseY, width/2, height/2) < 70) // if mouse postion is within the radius of the circle button...
  {
    if (!port.opened()) // if the port isn't open yet...
    {
      port.open(baudRate); // open the serial port (choose your board in the browser pop-up)
    }

    rxFlag = !rxFlag; // toggle the rxFlag

    if (rxFlag) //if rxFlag is true, we want to receive data, so...
    {
      port.write('A'); // send 'A' to the serial port to indicate that we want to receive data
    }
    else  //if rxFlag is false, we want to pause receiving data, so...
    {
      port.write('B'); // send 'B' to the serial port to indicate that we want to pause receiving data
    }
  }
}