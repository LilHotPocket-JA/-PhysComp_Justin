
const int adcPin_1 = 1;
const int adcPin_2 = 2;

const int ledPin = 4;
const int ledPin2 = 5;

int adcRead_1 = 0;
int adcRead_2 = 0;
int inByte = 0;

void setup() 
{
  pinMode(ledPin, OUTPUT);
  digitalWrite(ledPin, 0);  

  pinMode(ledPin2, OUTPUT);
  digitalWrite(ledPin2, 0);

  analogReadResolution(10); // set ADC range of 0 to 1023
  Serial.begin(115200);     // open serial port at 9600bps
}

void loop()
{
  if(Serial.available()) //if serial buffer is greater than zero...
  {
    inByte = Serial.read(); //store incoming byte
    
    if(inByte == 'A') //if incoming byte is 'A'...
    {
      digitalWrite(ledPin, 0);
      digitalWrite(ledPin2, 0);
      adcRead_1 = analogRead(adcPin_1); //read pot 1
      adcRead_2 = analogRead(adcPin_2); //read pot 2
    
      Serial.print(adcRead_1);      //send 3rd value
      Serial.print(',');            //send comma ASCII char to separate values
      Serial.print(adcRead_2);      //send 4th value
      Serial.print('\n');           //send newline ASCII char to frame end of message
    }

    else if(inByte == 'R') //if incoming byte is 'R'...
    {
      digitalWrite(ledPin, 1);
      delay(50);
      digitalWrite(ledPin,0);
      // adcRead_1 = analogRead(adcPin_1); //read pot 1
      // adcRead_2 = analogRead(adcPin_2); //read pot 2
    
      // Serial.print(adcRead_1);      //send 3rd value
      // Serial.print(',');            //send comma ASCII char to separate values
      // Serial.print(adcRead_2);      //send 4th value
      // Serial.print('\n');           //send newline ASCII char to frame end of message
    }

    else if(inByte == 'C') //if incoming byte is 'A'...
    {
      digitalWrite(ledPin2, 1);
       delay(50);
      digitalWrite(ledPin2,0);
      // adcRead_1 = analogRead(adcPin_1); //read pot 1
      // adcRead_2 = analogRead(adcPin_2); //read pot 2
    
      // Serial.print(adcRead_1);      //send 3rd value
      // Serial.print(',');            //send comma ASCII char to separate values
      // Serial.print(adcRead_2);      //send 4th value
      // Serial.print('\n');           //send newline ASCII char to frame end of message
    }

    else if (inByte == 'B') //if incoming byte is 'B'...
    {
      Serial.println("Sensor Update Paused...");  //send paused status message
      //using Serial.println adds a newline after each print, so no need for Serial.print('/n')
    }
    
    else //if incoming byte is neither 'A' nor 'B'...
    {
      Serial.println("Rx Byte is neither 'A' nor 'B'"); //send status message
    }
  }
}